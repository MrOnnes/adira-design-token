
//
// dart_size.dart
//

// Do not edit directly
// Generated on Wed, 07 Dec 2022 07:42:55 GMT



import 'dart:ui';

class adrSize {
  adrSize._();

    static const 12 = 12.00;
    static const 128 = 128.00;
    static const 16 = 16.00;
    static const 160 = 160.00;
    static const 192 = 192.00;
    static const 20 = 20.00;
    static const 224 = 224.00;
    static const 24 = 24.00;
    static const 256 = 256.00;
    static const 32 = 32.00;
    static const 4 = 4.00;
    static const 40 = 40.00;
    static const 48 = 48.00;
    static const 64 = 64.00;
    static const 8 = 8.00;
    static const 80 = 80.00;
    static const 96 = 96.00;
    static const borderDialog = 1.00;
    static const buttonGap = 8.00;
    static const buttonHeight = 40.00;
    static const buttonPaddingRightLeft = 24.00;
    static const buttonPaddingTopBottom = 8.00;
    static const buttonRadius = 28.00;
    static const cardRadius = 12.00;
    static const checkboxRadius = 4.00;
    static const chipRadius = 8.00;
    static const dialogRadius = 4.00;
    static const fieldGap = 8.00;
    static const fieldPaddingRightLeft = 24.00;
    static const fieldPaddingTopBottom = 8.00;
    static const fieldRadius = 8.00;
    static const fontBody1 = 16.00;
    static const fontBody2 = 14.00;
    static const fontButton1 = 12.00;
    static const fontButton2 = 14.00;
    static const fontCaption = 12.00;
    static const fontHeading1 = 30.00;
    static const fontHeading2 = 24.00;
    static const fontHeading3 = 20.00;
    static const fontHeading4 = 18.00;
    static const fontHeading5 = 16.00;
    static const fontLabel = 12.00;
    static const fontSubtitle1 = 16.00;
    static const fontSubtitle2 = 14.00;
    static const lineHeightBody1 = 24.00;
    static const lineHeightBody2 = 20.00;
    static const lineHeightButton1 = 24.00;
    static const lineHeightButton2 = 20.00;
    static const lineHeightCaption = 18.00;
    static const lineHeightH1 = 38.00;
    static const lineHeightH2 = 32.00;
    static const lineHeightH3 = 30.00;
    static const lineHeightH4 = 28.00;
    static const lineHeightH5 = 24.00;
    static const lineHeightLabel = 18.00;
    static const lineHeightSubtitle1 = 24.00;
    static const lineHeightSubtitle2 = 20.00;
    static const radiusExtraLarge = 28.00;
    static const radiusExtraSmall = 4.00;
    static const radiusFull = 100.00;
    static const radiusLarge = 16.00;
    static const radiusMedium = 12.00;
    static const radiusSmall = 8.00;
    static const space12 = 12.00;
    static const space16 = 16.00;
    static const space20 = 20.00;
    static const space24 = 24.00;
    static const space32 = 32.00;
    static const space4 = 4.00;
    static const space8 = 8.00;
}