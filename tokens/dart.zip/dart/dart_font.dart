
//
// dart_font.dart
//

// Do not edit directly
// Generated on Wed, 07 Dec 2022 07:42:55 GMT



import 'dart:ui';

class adrFont {
  adrFont._();

    static const body1FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const body1FontSize = 16.0;
    static const body1FontWeight = 400;
    static const body1LetterSpacing = "0%";
    static const body1LineHeight = 24;
    static const body1ParagraphSpacing = 16;
    static const body1TextCase = "none";
    static const body1TextDecoration = "none";
    static const body2FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const body2FontSize = 14.0;
    static const body2FontWeight = 400;
    static const body2LetterSpacing = "0%";
    static const body2LineHeight = 20;
    static const body2ParagraphSpacing = 14;
    static const body2TextCase = "none";
    static const body2TextDecoration = "none";
    static const button1FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const button1FontSize = 12.0;
    static const button1FontWeight = 600;
    static const button1LetterSpacing = "0%";
    static const button1LineHeight = 24;
    static const button1ParagraphSpacing = 16;
    static const button1TextCase = "none";
    static const button1TextDecoration = "none";
    static const button2FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const button2FontSize = 14.0;
    static const button2FontWeight = 500;
    static const button2LetterSpacing = "0%";
    static const button2LineHeight = 20;
    static const button2ParagraphSpacing = 14;
    static const button2TextCase = "none";
    static const button2TextDecoration = "none";
    static const captionFontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const captionFontSize = 12.0;
    static const captionFontWeight = 400;
    static const captionLetterSpacing = "0%";
    static const captionLineHeight = 18;
    static const captionParagraphSpacing = 12;
    static const captionTextCase = "none";
    static const captionTextDecoration = "none";
    static const familySans = -apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol';
    static const h1FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const h1FontSize = 30.0;
    static const h1FontWeight = 600;
    static const h1LetterSpacing = "0%";
    static const h1LineHeight = 38;
    static const h1ParagraphSpacing = 30;
    static const h1TextCase = "none";
    static const h1TextDecoration = "none";
    static const h2FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const h2FontSize = 24.0;
    static const h2FontWeight = 600;
    static const h2LetterSpacing = "0%";
    static const h2LineHeight = 32;
    static const h2ParagraphSpacing = 24;
    static const h2TextCase = "none";
    static const h2TextDecoration = "none";
    static const h3FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const h3FontSize = 20.0;
    static const h3FontWeight = 600;
    static const h3LetterSpacing = "0%";
    static const h3LineHeight = 30;
    static const h3ParagraphSpacing = 20;
    static const h3TextCase = "none";
    static const h3TextDecoration = "none";
    static const h4FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const h4FontSize = 18.0;
    static const h4FontWeight = 600;
    static const h4LetterSpacing = "0%";
    static const h4LineHeight = 28;
    static const h4ParagraphSpacing = 18;
    static const h4TextCase = "none";
    static const h4TextDecoration = "none";
    static const h5FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const h5FontSize = 16.0;
    static const h5FontWeight = 500;
    static const h5LetterSpacing = "0%";
    static const h5LineHeight = 24;
    static const h5ParagraphSpacing = 16;
    static const h5TextCase = "none";
    static const h5TextDecoration = "none";
    static const labelFontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const labelFontSize = 12.0;
    static const labelFontWeight = 600;
    static const labelLetterSpacing = "0%";
    static const labelLineHeight = 18;
    static const labelParagraphSpacing = 12;
    static const labelTextCase = "none";
    static const labelTextDecoration = "none";
    static const lineHeight0 = 38;
    static const lineHeight1 = 32;
    static const lineHeight10 = 44;
    static const lineHeight2 = 30;
    static const lineHeight3 = 28;
    static const lineHeight4 = 24;
    static const lineHeight5 = 20;
    static const lineHeight6 = 18;
    static const lineHeight7 = 90;
    static const lineHeight8 = 72;
    static const lineHeight9 = 60;
    static const subtitle1FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const subtitle1FontSize = 16.0;
    static const subtitle1FontWeight = 700;
    static const subtitle1LetterSpacing = "0%";
    static const subtitle1LineHeight = 24;
    static const subtitle1ParagraphSpacing = 16;
    static const subtitle1TextCase = "none";
    static const subtitle1TextDecoration = "none";
    static const subtitle2FontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";
    static const subtitle2FontSize = 14.0;
    static const subtitle2FontWeight = 700;
    static const subtitle2LetterSpacing = "0%";
    static const subtitle2LineHeight = 20;
    static const subtitle2ParagraphSpacing = 14;
    static const subtitle2TextCase = "none";
    static const subtitle2TextDecoration = "none";
    static const weightBold = FontWeight.w700;
    static const weightMedium = FontWeight.w500;
    static const weightRegular = FontWeight.w400;
    static const weightSemibold = FontWeight.w600;
}